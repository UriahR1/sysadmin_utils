#!/usr/bin/env bash

set -euo pipefail

# Sourcing the config file to assign variables

source "$(dirname "$0")/config.env"

filecount=$(find "$BACKUP_DIR" -name "*.tar.gz" -type f | wc -l)

if [[ "$filecount" -gt "$MAX_BACKUPS" ]]; then
	oldest=$(ls -t "$BACKUP_DIR"/*.tar.gz | tail -n 1)
#       rm "$oldest"
#       basename "$oldest" ".tar.gz"	
fi

